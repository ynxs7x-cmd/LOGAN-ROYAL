using UnityEngine;

namespace LoganRoyal
{
    [RequireComponent(typeof(CharacterController))]
    public class ThirdPersonPlayerController : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] private float moveSpeed = 5f;
        [SerializeField] private float rotationSpeed = 12f;
        [SerializeField] private float jumpHeight = 1.2f;
        [SerializeField] private float gravity = -20f;
        [SerializeField] private Transform cameraTransform;

        private CharacterController controller;
        private Vector3 verticalVelocity;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (Camera.main != null && cameraTransform == null)
                cameraTransform = Camera.main.transform;
        }

        private void Update()
        {
            // Keyboard input for the first desktop prototype.
            // Replace/extend with Unity Input System touch controls for Android.
            float x = Input.GetAxisRaw("Horizontal");
            float z = Input.GetAxisRaw("Vertical");
            Vector3 input = new Vector3(x, 0f, z).normalized;

            Vector3 move = input;
            if (cameraTransform != null)
            {
                Vector3 forward = cameraTransform.forward;
                Vector3 right = cameraTransform.right;
                forward.y = 0f;
                right.y = 0f;
                forward.Normalize();
                right.Normalize();
                move = (forward * input.z + right * input.x).normalized;
            }

            if (move.sqrMagnitude > 0.01f)
            {
                Quaternion targetRotation = Quaternion.LookRotation(move, Vector3.up);
                transform.rotation = Quaternion.Slerp(
                    transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
            }

            controller.Move(move * moveSpeed * Time.deltaTime);

            if (controller.isGrounded && verticalVelocity.y < 0f)
                verticalVelocity.y = -2f;

            if (controller.isGrounded && Input.GetButtonDown("Jump"))
                verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);

            verticalVelocity.y += gravity * Time.deltaTime;
            controller.Move(verticalVelocity * Time.deltaTime);
        }

        public void SetCamera(Transform targetCamera) => cameraTransform = targetCamera;
    }
}
