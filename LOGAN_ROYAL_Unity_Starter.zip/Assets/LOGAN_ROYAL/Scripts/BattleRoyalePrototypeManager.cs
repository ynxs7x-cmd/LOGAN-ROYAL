using UnityEngine;

namespace LoganRoyal
{
    public class BattleRoyalePrototypeManager : MonoBehaviour
    {
        [Header("Prototype state")]
        [SerializeField] private int startingHealth = 100;
        [SerializeField] private float safeZoneRadius = 80f;
        [SerializeField] private float zoneShrinkPerSecond = 0.1f;

        public int Health { get; private set; }
        public float SafeZoneRadius => safeZoneRadius;

        private void Start()
        {
            Health = startingHealth;
            Debug.Log($"LOGAN ROYAL prototype started. Health: {Health}, safe zone: {safeZoneRadius}m");
        }

        private void Update()
        {
            // Placeholder for a future match phase / safe-zone system.
            safeZoneRadius = Mathf.Max(10f, safeZoneRadius - zoneShrinkPerSecond * Time.deltaTime);
        }

        public void ApplyDamage(int amount)
        {
            if (amount <= 0) return;
            Health = Mathf.Max(0, Health - amount);
            if (Health == 0)
                Debug.Log("Player eliminated in prototype. Add respawn or match-end flow next.");
        }

        public bool IsInsideSafeZone(Vector3 worldPosition)
        {
            Vector2 point = new Vector2(worldPosition.x, worldPosition.z);
            return point.magnitude <= safeZoneRadius;
        }
    }
}
