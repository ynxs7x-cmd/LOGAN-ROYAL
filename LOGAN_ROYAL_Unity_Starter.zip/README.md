# LOGAN ROYAL — Unity Starter

Protótipo inicial de um battle royale 3D original para Android.

## Requisitos
- Unity Hub
- Unity 2022.3 LTS ou versão LTS mais recente
- Android Build Support (SDK, NDK e OpenJDK instalados pelo Unity Hub)

## Começar
1. Crie um projeto Unity 3D (Core) chamado `LOGAN_ROYAL`.
2. Copie a pasta `Assets/LOGAN_ROYAL` deste pacote para a pasta `Assets` do projeto Unity.
3. Na cena, crie um objeto `Player` (Capsule) e adicione `ThirdPersonPlayerController`.
4. Crie uma câmera e adicione `ThirdPersonCamera`; arraste o Player para o campo `Target`.
5. Crie um objeto vazio `GameManager` e adicione `BattleRoyalePrototypeManager`.
6. Pressione Play para testar no computador. O controle inicial usa WASD/setas e mouse.
7. Para Android, configure `File > Build Settings > Android > Switch Platform`, depois ajuste `Player Settings`.

## Estrutura
- `Assets/LOGAN_ROYAL/Scripts/ThirdPersonPlayerController.cs`: movimento inicial, pulo e controle por teclado.
- `Assets/LOGAN_ROYAL/Scripts/ThirdPersonCamera.cs`: câmera simples em terceira pessoa.
- `Assets/LOGAN_ROYAL/Scripts/BattleRoyalePrototypeManager.cs`: estado inicial de vida e zona segura demonstrativa.
- `Assets/LOGAN_ROYAL/Scripts/README_SETUP.md`: montagem da cena.

## Próximas etapas
1. Controles de toque e HUD para celular.
2. Coleta de armas e munição.
3. Alvos de treino e sistema de dano.
4. Zona segura com redução gradual.
5. Lobby e partidas online com servidor autoritativo.

Este pacote é um ponto de partida, não um jogo completo. O multiplayer online, modelos 3D, animações, efeitos, áudio e otimização Android ainda precisam ser implementados.
